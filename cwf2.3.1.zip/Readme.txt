@Version 2.3 stable
Thank you for installing CWFramework, CWFramework is powerful yet lightweight framework for your startup website.

For complete documentation and support feel free to visit official website of Cwframework http://www.cwframework.com
