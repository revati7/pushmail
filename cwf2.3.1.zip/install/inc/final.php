<h1>Congratulation !</h1>
<p>You have successfully setup the framework, now you can start code!!. </p>
<?php $path = rtrim($_SERVER['REQUEST_URI'],"/install/?r=final")."/";?>
<p>For any thing you didnot understand refer <a href='http://cwframework.com/docs'>documentation</a></p>
<p>Website is live on <a href="<?php echo "http://".$_SERVER['HTTP_HOST'].$path;?>"><?php echo "http://".$_SERVER['HTTP_HOST'].$path;?></a></p>