                            <?php
                           	@session_start();
                           	require "views/dashboard-files/".$_SESSION['user_type'].".php";
                           ?>     
                            