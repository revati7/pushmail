<ul class="nav nav-pills">
<li <?php echo (@$this->stag == 'add' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>gallery/add">Create Gallery</a></li>
<li <?php echo (@$this->stag == 'addImages' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>gallery/addImages">Add Images</a></li>
<li <?php echo (@$this->stag == 'view' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>gallery/view">View Gallery</a></li>
</ul>
                            
                            