<ul class="nav nav-pills">

<li <?php echo (@$this->stag == 'view' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>events/view">View Events</a></li>
<li <?php echo (@$this->stag == 'add' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>events/add">Add Event</a></li>
</ul>

                            