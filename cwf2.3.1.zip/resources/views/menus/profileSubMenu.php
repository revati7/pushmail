<ul class="nav nav-pills">
<!--li <?php echo (@$this->stag == 'accountSettings' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>members/settings">Account settings</a></li-->
<li <?php echo (@$this->stag == 'privacySettings' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>members/settings/privacy">Privacy settings</a></li>
<li <?php echo (@$this->stag == 'profileSettings' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>members/editProfile">Profile settings</a></li>

</ul>
                            