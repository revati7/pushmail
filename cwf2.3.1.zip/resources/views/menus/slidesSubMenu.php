<ul class="nav nav-pills">
<li <?php echo (@$this->stag == 'add' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>slides/add">Add Slide</a></li>
<li <?php echo (@$this->stag == 'view' ? 'class="active"':'');?>><a href="<?php echo _PATH_;?>slides/view">View Slides</a></li>

</ul>
                            
