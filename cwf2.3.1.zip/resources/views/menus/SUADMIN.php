<ul class="nav nav-list well">

	<li class='nav-header'>MASTER</li>
	<li class="<?php echo ($this->tag == 'members'?'active':'');?>"><a href="<?php echo _PATH_;?>members/view" >Manage Members</a></li>
	<li class="<?php echo ($this->tag == 'gallery'?'active':'');?>"><a href="<?php echo _PATH_;?>gallery/view" >Manage Gallery</a></li>

	<li class="<?php echo ($this->tag == 'events'?'active':'');?>"><a href='<?php echo _PATH_;?>events/view'>Event Management</a></li>

	<li class="<?php echo ($this->tag == 'slides' ? 'active':'');?>"><a href="<?php echo _PATH_;?>slides/view">Slides</a></li>
    
	</ul>                                

                            

                            

                            

                            
