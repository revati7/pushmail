<?php $this->section("header"); ?>
<div class="jumbotron" style="background:url('<?php echo _PATH_;?>resources/public/img/slides/859db1c0836cd0efe389af40e5034a4a.jpg') center;color:#000;">
    <div class='overlay'></div>
<div class="container">
    <div class="row" style='text-align:right'>
        <h1>CW Framework Has been Installed Successfully</h1>
        <p>This is an Home page or Default page. </p>
        <a href='<?php echo _PATH_;?>' class="btn btn-primary">GET STARTED</a>
    </div>
</div>
</div>
<div class="container">
	<h2 class='ui-feature-headling'>Features</h2>
	<div class="row">
		<div class="col-md-3">
			<div class='ui-feature-box'>
				<div class='ui-feature-title'>ABC</div>
				<div class='ui-feature-image' style="background:url('<?php echo _PATH_;?>resources/public/img/featured/img1.png');"></div>
				<div class='ui-feature-footer'>
					<p>Some text here</p>
					
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class='ui-feature-box'>
				<div class='ui-feature-title'>ABC</div>
				<div class='ui-feature-image' style="background:url('<?php echo _PATH_;?>resources/public/img/featured/img1.png');"></div>
				<div class='ui-feature-footer'>
					<p>Some text here</p>
					
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class='ui-feature-box'>
				<div class='ui-feature-title'>ABC</div>
				<div class='ui-feature-image' style="background:url('<?php echo _PATH_;?>resources/public/img/featured/img1.png');"></div>
				<div class='ui-feature-footer'>
					<p>Some text here</p>
					
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class='ui-feature-box'>
				<div class='ui-feature-title'>ABC</div>
				<div class='ui-feature-image' style="background:url('<?php echo _PATH_;?>resources/public/img/featured/img1.png');"></div>
				<div class='ui-feature-footer'>
					<p>Some text here</p>
					
				</div>
			</div>
		</div>
	</div>
</div>
<div class="jumbotron" style="background:url('<?php echo _PATH_;?>resources/public/img/slides/whatappmark-banner1.png');background-position:center;color:#000;background-size:100%;">
<div class='overlay'></div>
<div class="container">
    <div class="row">
        <h1>Documentation</h1>
        <p>If you have any queries just refer the official documentation.  </p>
        <a href='http://cwframework.com/docs' class="btn btn-primary">READ DOCS</a>
    </div>
</div>
</div>
<?php $this->section("footer");?>