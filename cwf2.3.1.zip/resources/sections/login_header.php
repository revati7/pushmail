<html>

    <head>

        <meta charset="utf-8" />

        <meta name="viewport" content="width=device-width,initial-scale=1.0" />

        <title><?php echo $this->title; ?></title>
		<link rel="shortcut icon" href="<?php echo _PATH_; ?>public/img/logo.png" />
        <link rel="stylesheet" type='text/css' href='<?php echo _PATH_; ?>public/css/bootstrap.css' />

        <link rel="stylesheet" type='text/css' href='<?php echo _PATH_; ?>public/css/bootstrap-responsive.css' />

        <link rel="stylesheet" type="text/css" href="<?php echo _PATH_; ?>public/css/theme.css" />
        <script>
            var _PATH_ = "<?php echo _PATH_; ?>";
        </script>
    </head>

    <body>
<br>

        
