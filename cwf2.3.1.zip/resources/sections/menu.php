<ul class="nav nav-pills nav-stacked menu-card">

	<li class='nav-header'>Youtube</li>
	<li class="<?php echo ($this->tag == 'channel'?'active':'');?>"><a href="<?php echo _PATH_;?>youtube/channel.html" >My Channels</a></li>
	<li class="<?php echo ($this->tag == 'postVideo'?'active':'');?>"><a href="<?php echo _PATH_;?>youtube/post-video.html" >My Posts</a></li>
    <li class='nav-header'>Website</li>
	<li class="<?php echo ($this->tag == 'website'?'active':'');?>"><a href='<?php echo _PATH_;?>website/post-link.html'>My Website</a></li>
	</ul>                                

                            

                            

                            

                            
