                                <br>
<div class='container'>
	<div class='footer-nav'>
	<ul>
		<li><a href=''>Home</a></li>
	</ul>
	</div>
</div>
<script type='text/javascript' src='<?php echo _PATH_;?>public/js/jquery.js'></script>

<script type='text/javascript' src='<?php echo _PATH_;?>public/js/bootstrap.js' ></script>

<script type="text/javascript" src="<?php echo _PATH_;?>public/js/main.js"></script>

</body>

</html>
           
                            