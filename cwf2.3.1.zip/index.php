<html>
<head>
</head>
<body>
	<script>window.location='./install';</script>
</body>
</html>