<?php 
class Media {
    function __construct(){
        
    }
    
}
?>